package com.example.eazy.dto.usuario;

public record UsuarioLoginDTO
        (
                String email,
                String senha
        ){}
